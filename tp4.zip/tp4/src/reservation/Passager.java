package reservation;

public class Passager{
    /***** Attributs *****/ 
    private String nom;

    /***** Methodes *****/ 
    public String getNom(){
        return nom;
    }

}